package com.example.bai5.repository;

import com.example.bai5.entity.NhanVien;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface NhanVienRepository extends JpaRepository<NhanVien, Integer> {

    @Query("""
            SELECT nv FROM NhanVien nv
            """)
    Page<NhanVien> pagingNhanVien(Pageable pageable);
}
