package com.example.bai5.service;

import com.example.bai5.entity.ChucVu;
import com.example.bai5.entity.NhanVien;
import com.example.bai5.repository.ChucVuRepository;
import com.example.bai5.repository.NhanVienRepository;
import com.example.bai5.request.NhanVienRequest;
import com.example.bai5.response.NhanVienResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

@Service
public class NhanVienService {

    @Autowired
    private NhanVienRepository nhanVienRepository;

    @Autowired
    private ChucVuRepository chucVuRepository;

    public List<NhanVienResponse> getAll(){
        List<NhanVienResponse> listResponse = new ArrayList<>();
        List<NhanVien> listNhanVien = nhanVienRepository.findAll();
        for (NhanVien nhanVien : listNhanVien){
            listResponse.add(convertToResponse(nhanVien));
        }
        return listResponse;
    }

    private NhanVienResponse convertToResponse(NhanVien nhanVien){
        NhanVienResponse response = new NhanVienResponse();
        response.setId(nhanVien.getId());
        response.setMaNhanVien(nhanVien.getMaNhanVien());
        response.setTenNhanVien(nhanVien.getTenNhanVien());
        response.setGioiTinh(nhanVien.getGioiTinh());
        response.setTuoi(tinhTuoi(nhanVien));
        response.setTenChucVu(nhanVien.getChucVu().getTenChucVu());
        return response;
    }

    private Integer tinhTuoi(NhanVien nhanVien){
        LocalDate tuoi = LocalDate.parse(nhanVien.getNgaySinh());
        return Period.between(tuoi, LocalDate.now()).getYears();
    }

    public NhanVienResponse detailNhanVien(Integer id){
        NhanVien nhanVien = nhanVienRepository.findById(id).get();
        return convertToResponse(nhanVien);
    }

    public Page<NhanVienResponse> pagingNhanVien(Integer pageNo, Integer pageSize){
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        Page<NhanVien> pageNhanVien = nhanVienRepository.pagingNhanVien(pageable);
        return pageNhanVien.map(this::convertToResponse);
    }

    public void addNhanVien(NhanVienRequest request){
        NhanVien nhanVien = new NhanVien();
        BeanUtils.copyProperties(request, nhanVien);
        ChucVu chucVu = chucVuRepository.findById(request.getChucVuId()).orElse(null);
        nhanVien.setChucVu(chucVu);
        nhanVienRepository.save(nhanVien);
    }

    public void updateNhanVien(NhanVienRequest request, Integer id){
        NhanVien nhanVien = nhanVienRepository.findById(id).orElseThrow();
        BeanUtils.copyProperties(request, nhanVien);
        ChucVu chucVu = chucVuRepository.findById(request.getChucVuId()).orElse(null);
        nhanVien.setId(id);
        nhanVien.setChucVu(chucVu);
        nhanVienRepository.save(nhanVien);
    }

    public void deleteNhanVien(Integer id){
        nhanVienRepository.deleteById(id);
    }
}
