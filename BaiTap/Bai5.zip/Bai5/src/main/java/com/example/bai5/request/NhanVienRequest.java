package com.example.bai5.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class NhanVienRequest {

    private String maNhanVien;

    private String tenNhanVien;

    private Boolean gioiTinh;

    private String ngaySinh;

    private Integer chucVuId;
}
