package com.example.bai5.controller;

import com.example.bai5.entity.NhanVien;
import com.example.bai5.request.NhanVienRequest;
import com.example.bai5.response.NhanVienResponse;
import com.example.bai5.service.NhanVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/nhan-vien")
public class NhanVienController {

    @Autowired
    private NhanVienService nhanVienService;

    @GetMapping
    public List<NhanVienResponse> getAll(){
        return nhanVienService.getAll();
    }

    @GetMapping("/detail/{id}")
    public NhanVienResponse detailNhanVien(@PathVariable Integer id){
        return nhanVienService.detailNhanVien(id);
    }

    @GetMapping("/paging")
    public List<NhanVienResponse> pagingNhanVien(@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
                                                 @RequestParam(name = "pageSize", defaultValue = "3") Integer pageSize){
        return nhanVienService.pagingNhanVien(pageNo, pageSize).getContent();
    }

    @PostMapping("/add")
    public String addNhanVien(@RequestBody NhanVienRequest request){
        nhanVienService.addNhanVien(request);
        return "Thêm thành công !";
    }

    @PutMapping("/update/{id}")
    public String updateNhanVien(@RequestBody NhanVienRequest request, @PathVariable Integer id){
        nhanVienService.updateNhanVien(request, id);
        return "Sửa thành công !";
    }

    @DeleteMapping("/delete/{id}")
    public String deleteNhanVVien(@PathVariable Integer id){
        nhanVienService.deleteNhanVien(id);
        return "Xóa thành công !";
    }
}
