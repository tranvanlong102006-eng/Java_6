package com.example.bai3.response;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class BacSiResponse {

    private Integer id;

    private String tenBacSi;

    private Integer tuoi;

    private Boolean gioiTinh;

    private String tenBenhVien;

    private String diaChi;
}
