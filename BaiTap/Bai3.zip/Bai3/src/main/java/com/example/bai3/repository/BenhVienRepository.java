package com.example.bai3.repository;

import com.example.bai3.entity.BenhVien;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BenhVienRepository extends JpaRepository<BenhVien, Integer> {
}
