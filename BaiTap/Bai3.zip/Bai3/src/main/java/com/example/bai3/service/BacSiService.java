package com.example.bai3.service;

import com.example.bai3.entity.BacSi;
import com.example.bai3.entity.BenhVien;
import com.example.bai3.repository.BacSiRepository;
import com.example.bai3.repository.BenhVienRepository;
import com.example.bai3.request.BacSiRequest;
import com.example.bai3.response.BacSiResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BacSiService {

    @Autowired
    private BacSiRepository bacSiRepository;

    @Autowired
    private BenhVienRepository benhVienRepository;

    public List<BacSiResponse> getAll(){
        List<BacSiResponse> listResponse = new ArrayList<>();
        List<BacSi> listBacSi = bacSiRepository.findAll();
        for (BacSi bacSi : listBacSi){
            listResponse.add(convertToResponse(bacSi));
        }
        return listResponse;
    }

    private BacSiResponse convertToResponse(BacSi bacSi){
        BacSiResponse response = new BacSiResponse();
        response.setId(bacSi.getId());
        response.setTenBacSi(bacSi.getTenBacSi());
        response.setTuoi(bacSi.getTuoi());
        response.setGioiTinh(bacSi.getGioiTinh());
        response.setTenBenhVien(bacSi.getBenhVien().getTenBenhVien());
        response.setDiaChi(bacSi.getBenhVien().getDiaChi());
        return response;
    }

    public BacSiResponse detailBacSi(Integer id){
        return bacSiRepository.detailBacSi(id);
    }

    public Page<BacSiResponse> pagingBacSi(Integer pageNo, Integer pageSize){
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return bacSiRepository.pagingBacSi(pageable);
    }

    public void addBacSi(BacSiRequest request){
        BacSi bacSi = new BacSi();
        BeanUtils.copyProperties(request, bacSi);
        BenhVien benhVien = benhVienRepository.findById(request.getBenhVienId()).orElseThrow();
        bacSi.setBenhVien(benhVien);
        bacSiRepository.save(bacSi);
    }

    public void updateBacSi(BacSiRequest request, Integer id){
        BacSi bacSi = bacSiRepository.findById(id).orElseThrow();
        BeanUtils.copyProperties(request, bacSi);
        BenhVien benhVien = benhVienRepository.findById(request.getBenhVienId()).orElseThrow();
        bacSi.setId(id);
        bacSi.setBenhVien(benhVien);
        bacSiRepository.save(bacSi);
    }

    public void deleteBacSi(Integer id){
        bacSiRepository.deleteById(id);
    }
}
