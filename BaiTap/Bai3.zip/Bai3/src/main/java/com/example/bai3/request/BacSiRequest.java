package com.example.bai3.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class BacSiRequest {

    private String tenBacSi;

    private Integer tuoi;

    private Boolean gioiTinh;

    private Integer benhVienId;
}
