package com.example.bai3.repository;

import com.example.bai3.entity.BacSi;
import com.example.bai3.response.BacSiResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BacSiRepository extends JpaRepository<BacSi, Integer> {

    @Query("""
            SELECT NEW com.example.bai3.response.BacSiResponse(
            bs.id, 
            bs.tenBacSi,
            bs.tuoi, 
            bs.gioiTinh, 
            bv.tenBenhVien,
            bv.diaChi)
            FROM 
            BacSi bs
            JOIN BenhVien bv ON bs.benhVien.id = bv.id
            WHERE bs.id = ?1
            """)
    BacSiResponse detailBacSi(Integer id);

    @Query("""
            SELECT NEW com.example.bai3.response.BacSiResponse(
            bs.id, 
            bs.tenBacSi,
            bs.tuoi, 
            bs.gioiTinh, 
            bv.tenBenhVien,
            bv.diaChi)
            FROM 
            BacSi bs
            JOIN BenhVien bv ON bs.benhVien.id = bv.id
            """)
    Page<BacSiResponse> pagingBacSi(Pageable pageable);
}
