package com.example.bai3.controller;

import com.example.bai3.request.BacSiRequest;
import com.example.bai3.response.BacSiResponse;
import com.example.bai3.service.BacSiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bac-si")
public class BacSiController {

    @Autowired
    private BacSiService bacSiService;

    @GetMapping
    public List<BacSiResponse> getAll(){
        return bacSiService.getAll();
    }

    @GetMapping("/detail/{id}")
    public BacSiResponse detailBacSi(@PathVariable Integer id){
        return bacSiService.detailBacSi(id);
    }

    @GetMapping("/paging")
    public List<BacSiResponse> pagingBacSi (@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
                                            @RequestParam(name = "pageSize", defaultValue = "3") Integer pageSize){
        return bacSiService.pagingBacSi(pageNo, pageSize).getContent();
    }

    @PostMapping("/add")
    public void addBacSi(@RequestBody BacSiRequest request){
        bacSiService.addBacSi(request);
    }

    @PutMapping("/update/{id}")
    public void updateBacSi(@RequestBody BacSiRequest request, @PathVariable Integer id){
        bacSiService.updateBacSi(request, id);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteBacSi(@PathVariable Integer id){
        bacSiService.deleteBacSi(id);
    }
}
