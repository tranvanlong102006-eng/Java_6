package com.example.bai9.controller;

import com.example.bai9.request.NhanVienRequest;
import com.example.bai9.response.NhanVienResponse;
import com.example.bai9.service.NhanVienService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/nhan-vien")
public class NhanVienController {

    @Autowired
    private NhanVienService service;


    @GetMapping
    public List<NhanVienResponse> getAll(){
        return service.getAll1();
    }

    @GetMapping("/detail/{id}")
    public NhanVienResponse detail(@PathVariable Integer id){
        return service.detailNhanVien(id);
    }

    @GetMapping("/paging")
    public List<NhanVienResponse> paging (@RequestParam(value = "pageNo", defaultValue = "0") Integer pageNo,
                                          @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize){
        return service.pagingNhanVien(pageNo, pageSize).getContent();
    }

    @GetMapping("/search")
    public List<NhanVienResponse> searchNhanVien(@RequestParam("ten") String tenNhanVien){
        return service.searchNhanVien(tenNhanVien);
    }

    @PostMapping("/add")
    public String add(@Valid @RequestBody NhanVienRequest request){
        service.addNhanVien(request);
        return "Thêm thành công!";
    }

    @PutMapping("/update/{id}")
    public String add(@Valid @RequestBody NhanVienRequest request, @PathVariable Integer id){
        service.updateNhanVien(request, id);
        return "Sửa thành công!";
    }

    @DeleteMapping("/delete/{id}")
    public String add(@PathVariable Integer id){
        service.deleteNhanVien(id);
        return "Sửa thành công!";
    }
}
