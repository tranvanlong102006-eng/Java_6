package com.example.bai9.repository;

import com.example.bai9.entity.NhanVien;
import com.example.bai9.response.NhanVienResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NhanVienRepository extends JpaRepository<NhanVien, Integer> {


    @Query("""
            SELECT NEW com.example.bai9.response.NhanVienResponse(nv.id, nv.ma, nv.ten, nv.gioiTinh, nv.ngaySinh, nv.diaChi, nv.matKhau)
            FROM NhanVien nv
            WHERE nv.id = ?1
            """)
    NhanVienResponse detailNhanVien(Integer id);

    @Query("""
            SELECT NEW com.example.bai9.response.NhanVienResponse(nv.id, nv.ma, nv.ten, nv.gioiTinh, nv.ngaySinh, nv.diaChi, nv.matKhau)
            FROM NhanVien nv
            """)
    Page<NhanVienResponse> pagingNhanVien(Pageable pageable);

    @Query("""
            SELECT NEW com.example.bai9.response.NhanVienResponse(nv.id, nv.ma, nv.ten, nv.gioiTinh, nv.ngaySinh, nv.diaChi, nv.matKhau)
            FROM NhanVien nv
            WHERE nv.ten LIKE %:ten%
            """)
    List<NhanVienResponse> searchNhanVien(@Param("ten") String tenNhanVien);

    List<NhanVien> findAllByOrderByMaAsc();
}
