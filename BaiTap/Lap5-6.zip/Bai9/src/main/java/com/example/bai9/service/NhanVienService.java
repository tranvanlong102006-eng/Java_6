package com.example.bai9.service;

import com.example.bai9.entity.NhanVien;
import com.example.bai9.repository.NhanVienRepository;
import com.example.bai9.request.NhanVienRequest;
import com.example.bai9.response.NhanVienResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class NhanVienService {

    @Autowired
    private NhanVienRepository nhanVienRepository;

    public List<NhanVienResponse> getAll(){
        List<NhanVienResponse> listResponse = new ArrayList<>();
        List<NhanVien> listNhanVien = nhanVienRepository.findAll();
        for (NhanVien nhanVien : listNhanVien){
            listResponse.add(convertToResponse(nhanVien));
        }
        return listResponse;
    }

    private NhanVienResponse convertToResponse(NhanVien nhanVien){
        NhanVienResponse response = new NhanVienResponse();
        response.setId(nhanVien.getId());
        response.setMa(nhanVien.getMa());
        response.setTen(nhanVien.getTen());
        response.setGioiTinh(nhanVien.getGioiTinh());
        response.setNgaySinh(nhanVien.getNgaySinh());
        response.setDiaChi(nhanVien.getDiaChi());
        response.setMatKhau(nhanVien.getMatKhau());
        return response;
    }

    public NhanVienResponse detailNhanVien(Integer id){
        return nhanVienRepository.detailNhanVien(id);
    }

    public Page<NhanVienResponse> pagingNhanVien(Integer pageNo, Integer pageSize){
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return nhanVienRepository.pagingNhanVien(pageable);
    }

    public List<NhanVienResponse> searchNhanVien(String tenNhanVien){
        return nhanVienRepository.searchNhanVien(tenNhanVien);
    }

    public List<NhanVienResponse> getAll1() {
        List<NhanVienResponse> listResponse = new ArrayList<>();
        // Gọi hàm đã có Order By
        List<NhanVien> listNhanVien = nhanVienRepository.findAllByOrderByMaAsc();

        for (NhanVien nhanVien : listNhanVien) {
            listResponse.add(convertToResponse(nhanVien));
        }
        return listResponse;
    }

    public void addNhanVien(NhanVienRequest request){
        NhanVien nhanVien = new NhanVien();
        BeanUtils.copyProperties(request, nhanVien);
        nhanVienRepository.save(nhanVien);
    }

    public void updateNhanVien(NhanVienRequest request, Integer id){
        NhanVien nhanVien = nhanVienRepository.findById(id).get();
        BeanUtils.copyProperties(request, nhanVien);
        nhanVienRepository.save(nhanVien);
    }

    public void deleteNhanVien(Integer id){
        nhanVienRepository.deleteById(id);
    }
}
