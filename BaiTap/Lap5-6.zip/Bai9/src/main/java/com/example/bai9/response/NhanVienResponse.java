package com.example.bai9.response;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class NhanVienResponse {
    /*Mã nhân viên, Tên nhân viên, Giới tính, Ngày sinh, Địa chỉ, Mật khẩu*/

    private Integer id;

    private String ma;

    private String ten;

    private Boolean gioiTinh;

    private String ngaySinh;

    private String diaChi;

    private String matKhau;
}
