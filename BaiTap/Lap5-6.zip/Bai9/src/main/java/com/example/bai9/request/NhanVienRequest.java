package com.example.bai9.request;

import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class NhanVienRequest {

    @NotBlank(message = "Mã không được để trống !")
    private String ma;

    @NotBlank(message = "Tên không được để trống !")
    private String ten;

    @NotNull(message = "Giới tính không đươc để trống !")
    private Boolean gioiTinh;

    @NotNull(message = "Ngày sinh không được để trống !")
    private String ngaySinh;

    @NotBlank(message = "Địa chỉ không được để trống !")
    private String diaChi;

    @NotBlank(message = "Mật khẩu không được để trống !")
    private String matKhau;
}
