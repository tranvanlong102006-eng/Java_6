package com.example.bai2.controller;

import com.example.bai2.request.GiangVienRequest;
import com.example.bai2.response.GiangVienResponse;
import com.example.bai2.service.GiangVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/giang-vien")
public class GiangVienController {

    @Autowired
    private GiangVienService giangVienService;

    @GetMapping
    public List<GiangVienResponse> getAll(){
        return giangVienService.getAll();
    }

    @GetMapping("/detail/{id}")
    public GiangVienResponse detailGiangVien(@PathVariable Integer id){
        return giangVienService.detailGiangVien(id);
    }

    @GetMapping("/paging")
    public List<GiangVienResponse> pagingGiangVien(@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
                                                   @RequestParam(name = "pageSize", defaultValue = "3") Integer pageSize){
        return giangVienService.pagingGiangVien(pageNo, pageSize).getContent();
    }

    @DeleteMapping("/remove/{id}")
    public void removeGiangVien(@PathVariable Integer id){
        giangVienService.removeGiangVien(id);
    }

    @PostMapping("/add")
    public void addGiangVien(@RequestBody GiangVienRequest request){
        giangVienService.addGiangVien(request);
    }

    @PutMapping("/update/{id}")
    public void updateGiangVien(@RequestBody GiangVienRequest request, @PathVariable Integer id){
        giangVienService.updateGiangVien(request, id);
    }
}
