package com.example.bai2.response;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class GiangVienResponse {

    private Integer id;

    private String ma;

    private String ten;

    private Integer tuoi;

    private Boolean gioiTinh;

    private String queQuan;
}
