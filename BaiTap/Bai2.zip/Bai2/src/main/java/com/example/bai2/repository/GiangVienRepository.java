package com.example.bai2.repository;

import com.example.bai2.entity.GiangVien;
import com.example.bai2.response.GiangVienResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GiangVienRepository extends JpaRepository<GiangVien, Integer> {

    @Query("""
            SELECT NEW com.example.bai2.response.GiangVienResponse(gv.id, gv.ma, gv.ten, gv.tuoi, gv.gioiTinh, gv.queQuan)
            FROM 
            GiangVien gv
            WHERE gv.id = ?1
            """)
    GiangVienResponse detailGiangVien(Integer id);

    @Query("""
            SELECT NEW com.example.bai2.response.GiangVienResponse(gv.id, gv.ma, gv.ten, gv.tuoi, gv.gioiTinh, gv.queQuan)
            FROM 
            GiangVien gv
                        
            """)
    Page<GiangVienResponse> pagingGiangVien(Pageable pageable);
}
