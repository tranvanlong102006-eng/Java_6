package com.example.bai2.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class GiangVienRequest {

    private String ma;

    private String ten;

    private Integer tuoi;

    private Boolean gioiTinh;

    private String queQuan;
}
