package com.example.bai2.service;

import com.example.bai2.entity.GiangVien;
import com.example.bai2.repository.GiangVienRepository;
import com.example.bai2.request.GiangVienRequest;
import com.example.bai2.response.GiangVienResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GiangVienService {

    @Autowired
    private GiangVienRepository giangVienRepository;

    public List<GiangVienResponse> getAll(){
        List<GiangVienResponse> listResponse = new ArrayList<>();
        List<GiangVien> listGiangVien = giangVienRepository.findAll();
        for (GiangVien gv : listGiangVien){
            listResponse.add(convertToResponse(gv));
        }
        return listResponse;
    }


    private GiangVienResponse convertToResponse(GiangVien gv){
        GiangVienResponse response = new GiangVienResponse();
        response.setId(gv.getId());
        response.setMa(gv.getMa());
        response.setTen(gv.getTen());
        response.setTuoi(gv.getTuoi());
        response.setGioiTinh(gv.getGioiTinh());
        response.setQueQuan(gv.getQueQuan());
        return response;
    }


    public GiangVienResponse detailGiangVien(Integer id){
        return giangVienRepository.detailGiangVien(id);
    }

    public Page<GiangVienResponse> pagingGiangVien(Integer pageNo, Integer pageSize){
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return giangVienRepository.pagingGiangVien(pageable);
    }

    public void removeGiangVien(Integer id){
        giangVienRepository.deleteById(id);
    }

    public void addGiangVien(GiangVienRequest request){
        GiangVien giangVien = new GiangVien();
        BeanUtils.copyProperties(request, giangVien);
        giangVienRepository.save(giangVien);
    }

    public void updateGiangVien(GiangVienRequest request, Integer id){
        GiangVien giangVien = giangVienRepository.findById(id).orElseThrow();
        BeanUtils.copyProperties(request, giangVien);
        giangVien.setId(id);
        giangVienRepository.save(giangVien);
    }
}
