package com.example.lap66;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lap66Application {

    public static void main(String[] args) {
        SpringApplication.run(Lap66Application.class, args);
    }

}
