package com.example.bai4.controller;

import com.example.bai4.request.SinhVienRequest;
import com.example.bai4.response.SinhVienResponse;
import com.example.bai4.service.SinhVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sinh-vien")
public class SinhVienController {

    @Autowired
    private SinhVienService sinhVienService;

    @GetMapping
    public List<SinhVienResponse> getAll(){
        return sinhVienService.getAll();
    }

    @GetMapping("/detail/{id}")
    public SinhVienResponse detailSinhVien(@PathVariable Integer id){
        return sinhVienService.detailSinhVien(id);
    }

    @GetMapping("/paging")
    public List<SinhVienResponse> pagingSinhVien(@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
                                                 @RequestParam(name = "pageSize", defaultValue = "3") Integer pageSize){
        return sinhVienService.pagingSinhVien(pageNo, pageSize).getContent();
    }

    @PostMapping("/add")
    public void addSinhVien(@RequestBody SinhVienRequest request){
        sinhVienService.addSinhVien(request);
    }

    @PutMapping("/update/{id}")
    public void updateSinhVien(@RequestBody SinhVienRequest request, @PathVariable Integer id){
        sinhVienService.updateSinhVien(request, id);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteSinhVien(@PathVariable Integer id){
        sinhVienService.deleteSinhVien(id);
    }
}
