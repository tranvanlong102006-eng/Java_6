package com.example.bai4.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class SinhVienRequest {

    private String maSV;

    private String tenSV;

    private Integer tuoi;

    private Boolean gioiTinh;

    private Integer lopId;
}
