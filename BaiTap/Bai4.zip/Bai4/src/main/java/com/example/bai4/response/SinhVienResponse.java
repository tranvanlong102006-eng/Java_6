package com.example.bai4.response;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class SinhVienResponse {

    private Integer id;

    private String maSV;

    private String tenSV;

    private Integer tuoi;

    private Boolean gioiTinh;

    private String maLop;

    private String tenLop;
}
