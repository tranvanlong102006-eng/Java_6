package com.example.bai4.repository;

import com.example.bai4.entity.SinhVien;
import com.example.bai4.response.SinhVienResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SinhVienRepository extends JpaRepository<SinhVien, Integer> {

    @Query("""
            SELECT NEW com.example.bai4.response.SinhVienResponse(sv.id, sv.maSV, sv.tenSV, sv.tuoi, sv.gioiTinh, l.maLop, l.tenLop)
            FROM 
            SinhVien sv
            JOIN Lop l ON sv.lop.id = l.id
            WHERE sv.id = ?1
            """)
    SinhVienResponse detailSinhVien(Integer id);

    @Query("""
            SELECT NEW com.example.bai4.response.SinhVienResponse(sv.id, sv.maSV, sv.tenSV, sv.tuoi, sv.gioiTinh, l.maLop, l.tenLop)
            FROM 
            SinhVien sv
            JOIN Lop l ON sv.lop.id = l.id
                      
            """)
    Page<SinhVienResponse> pagingSinhVien(Pageable pageable);
}
