package com.example.bai4.service;

import com.example.bai4.entity.Lop;
import com.example.bai4.entity.SinhVien;
import com.example.bai4.repository.LopRepository;
import com.example.bai4.repository.SinhVienRepository;
import com.example.bai4.request.SinhVienRequest;
import com.example.bai4.response.SinhVienResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SinhVienService {

    @Autowired
    private SinhVienRepository sinhVienRepository;

    @Autowired
    private LopRepository lopRepository;

    public List<SinhVienResponse> getAll(){
        List<SinhVienResponse> listResponse = new ArrayList<>();
        List<SinhVien> listSV = sinhVienRepository.findAll();
        for (SinhVien sinhVien : listSV){
            listResponse.add(convertToReponse(sinhVien));
        }

        return listResponse;
    }

    private SinhVienResponse convertToReponse(SinhVien sinhVien){
        SinhVienResponse response = new SinhVienResponse();
        response.setId(sinhVien.getId());
        response.setMaSV(sinhVien.getMaSV());
        response.setTenSV(sinhVien.getTenSV());
        response.setTuoi(sinhVien.getTuoi());
        response.setGioiTinh(sinhVien.getGioiTinh());
        response.setMaLop(sinhVien.getLop().getMaLop());
        response.setTenLop(sinhVien.getLop().getTenLop());
        return response;
    }

    public SinhVienResponse detailSinhVien(Integer id){
        return sinhVienRepository.detailSinhVien(id);
    }

    public Page<SinhVienResponse> pagingSinhVien(Integer pageNo, Integer pageSize){
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return sinhVienRepository.pagingSinhVien(pageable);
    }

    public void addSinhVien(SinhVienRequest request){
        SinhVien sv = new SinhVien();
        BeanUtils.copyProperties(request, sv);
        Lop lop = lopRepository.findById(request.getLopId()).orElseThrow();
        sv.setLop(lop);
        sinhVienRepository.save(sv);
    }

    public void updateSinhVien(SinhVienRequest request, Integer id){
        SinhVien sv = sinhVienRepository.findById(id).orElseThrow();
        BeanUtils.copyProperties(request, sv);
        Lop lop = lopRepository.findById(request.getLopId()).orElseThrow();
        sv.setId(id);
        sv.setLop(lop);
        sinhVienRepository.save(sv);
    }

    public void deleteSinhVien(Integer id){
        sinhVienRepository.deleteById(id);
    }
}
