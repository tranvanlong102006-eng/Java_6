package com.example.bai4.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name = "SinhVien")
public class SinhVien {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ma_sv")
    private String maSV;

    @Column(name = "ten")
    private String tenSV;

    @Column(name = "tuoi")
    private Integer tuoi;

    @Column(name = "gioiTinh")
    private Boolean gioiTinh;

    @ManyToOne
    @JoinColumn(name = "lop_id", referencedColumnName = "id")
    private Lop lop;
}
